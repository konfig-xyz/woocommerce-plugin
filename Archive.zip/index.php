<?php
/*
 * Plugin Name: Konfig
 * Plugin URI:  https://konfig.xyz
 * Description: Konfig enables interacting with Woocommerce Cart
 * Author:      Konfig Team
 * Version:     0.1.0
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */


// Register gutenberg block
include __DIR__ . "/block/index.php";
